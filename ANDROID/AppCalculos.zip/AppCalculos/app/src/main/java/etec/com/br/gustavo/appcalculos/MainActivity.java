package etec.com.br.gustavo.appcalculos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Objetos Java Para Referenciar Aos Objetos XML
    Button btSoma,btSubtrai,btDivide,btMultiplica;
    EditText edValor1,edValor2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Refenciar os objetos Java com Os Objetos XML

        edValor1 = findViewById(R.id.edtValor1);
        edValor2 = findViewById(R.id.edtValor2);
        btSoma = findViewById(R.id.btnSomar);
        btSubtrai = findViewById(R.id.btnSubtrair);
        btDivide = findViewById(R.id.btnDividir);
        btMultiplica = findViewById(R.id.btnMultiplica);

        //Preparando o Click Do Botão
        btSoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            //Variaveis Auxiliares
            float v1,v2,resultado;

            //Recuperando o Valor da Edt

               if (edValor1.getText().toString().isEmpty()){
                   edValor1.setError("Valor 1 Obrigatório");
                   edValor1.requestFocus();
                }
               else if (edValor2.getText().toString().isEmpty()){
                   edValor2.setError("Valor 2 Obrigatório");
                   edValor2.requestFocus();
               }
               else{
                   v1=Float.parseFloat(edValor1.getText().toString());
                   v2=Float.parseFloat(edValor2.getText().toString());
                   //Efetuando Calculo
                   resultado=v1+v2;

                   Toast.makeText(MainActivity.this, "Resultado Da Soma É: "+resultado, Toast.LENGTH_LONG).show();
               }

            }
        });

        btSubtrai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float v1,v2,resultado;

                if (edValor1.getText().toString().isEmpty()){
                    edValor1.setError("Valor 1 Obrigatório");
                    edValor1.requestFocus();
                }
                else if (edValor2.getText().toString().isEmpty()){
                    edValor2.setError("Valor 2 Obrigatório");
                    edValor2.requestFocus();
                }
                else{
                    v1=Float.parseFloat(edValor1.getText().toString());
                    v2=Float.parseFloat(edValor2.getText().toString());
                    resultado=v1-v2;

                    Toast.makeText(MainActivity.this, "Resultado Da Subtração É: "+resultado, Toast.LENGTH_LONG).show();
                }

            }
        });

        btDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float v1,v2,resultado;

                if (edValor1.getText().toString().isEmpty()){
                    edValor1.setError("Valor 1 Obrigatório");
                    edValor1.requestFocus();
                }
                else if (edValor2.getText().toString().isEmpty()){
                    edValor2.setError("Valor 2 Obrigatório");
                    edValor2.requestFocus();
                }
                else{
                    v1=Float.parseFloat(edValor1.getText().toString());
                    v2=Float.parseFloat(edValor2.getText().toString());
                    resultado=v1/v2;

                    Toast.makeText(MainActivity.this, "Resultado Da Divisão É: "+resultado, Toast.LENGTH_LONG).show();
                }
            }
        });

        btMultiplica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float v1,v2,resultado;

                if (edValor1.getText().toString().isEmpty()){
                    edValor1.setError("Valor 1 Obrigatório");
                    edValor1.requestFocus();
                }
                else if (edValor2.getText().toString().isEmpty()){
                    edValor2.setError("Valor 2 Obrigatório");
                    edValor2.requestFocus();
                }
                else{
                    v1=Float.parseFloat(edValor1.getText().toString());
                    v2=Float.parseFloat(edValor2.getText().toString());
                    resultado=v1*v2;

                    Toast.makeText(MainActivity.this, "Resultado Da Multiplicação É: "+resultado, Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}