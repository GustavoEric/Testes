package etec.com.br.gustavo.quizgustavoericalves;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class TelaPergunta6 extends AppCompatActivity {

    TextView tVNomeP6,tVPontosP6;
    RadioGroup rdgP6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_pergunta6);

        tVNomeP6 = findViewById(R.id.txtVNomeP6);
        tVPontosP6 = findViewById(R.id.txtVPontosP6);

        Intent telaAtual6 = getIntent();

        Bundle valoresRecebidos6 = telaAtual6.getExtras();

        tVPontosP6.setText(valoresRecebidos6.getString("PontosJogadorP5"));
        tVNomeP6.setText(valoresRecebidos6.getString("NomeJogador6"));
        rdgP6 = findViewById(R.id.rdgPergunta6);
    }
    public void butaoOKP6 (View v){
        Intent telaAtual6 = getIntent();

        Bundle valoresRecebidos6 = telaAtual6.getExtras();

        tVPontosP6.setText(valoresRecebidos6.getString("PontosJogadorP5"));
        String ponto = valoresRecebidos6.getString("PontosJogadorP5");

        int op = rdgP6.getCheckedRadioButtonId();
        int pontosP6 = Integer.parseInt(ponto);
        String somaStr= String.valueOf(pontosP6);
        Log.e("Pontos:",somaStr);

        if (op==R.id.rdbAP6){
            Toast.makeText(this, "Resposta Correta", Toast.LENGTH_SHORT).show();
            pontosP6 +=1;

        }
        else{
            Toast.makeText(this, "Resposta Errada", Toast.LENGTH_SHORT).show();
        }
        String pontoStr;
        pontoStr = String.valueOf(pontosP6);
        Log.e("Pontos Somados:",pontoStr);
        Intent TP7 = new Intent(TelaPergunta6.this,TelaPergunta7.class);
        TP7.putExtra("PontosJogadorP6",pontoStr);

        String nome6= tVNomeP6.getText().toString();
        TP7.putExtra("NomeJogador7",nome6);

        startActivity(TP7);

    }
}