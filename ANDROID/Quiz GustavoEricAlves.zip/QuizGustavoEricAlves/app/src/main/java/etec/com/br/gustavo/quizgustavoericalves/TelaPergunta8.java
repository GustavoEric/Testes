package etec.com.br.gustavo.quizgustavoericalves;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TelaPergunta8 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_pergunta8);
    }
}