package etec.com.br.gustavo.quizgustavoericalves;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class TelaPergunta7 extends AppCompatActivity {

    TextView tVNomeP7,tVPontosP7;
    RadioGroup rdgP7;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_pergunta7);

        tVNomeP7 = findViewById(R.id.txtVNomeP7);
        tVPontosP7 = findViewById(R.id.txtVPontosP7);

        Intent telaAtual7 = getIntent();

        Bundle valoresRecebidos7 = telaAtual7.getExtras();

        tVPontosP7.setText(valoresRecebidos7.getString("PontosJogadorP6"));
        tVNomeP7.setText(valoresRecebidos7.getString("NomeJogador7"));
        rdgP7 = findViewById(R.id.rdgPergunta7);
    }
    public void butaoOKP7 (View v){
        Intent telaAtual7 = getIntent();

        Bundle valoresRecebidos7 = telaAtual7.getExtras();

        tVPontosP7.setText(valoresRecebidos7.getString("PontosJogadorP6"));
        String ponto = valoresRecebidos7.getString("PontosJogadorP6");

        int op = rdgP7.getCheckedRadioButtonId();
        int pontosP7 = Integer.parseInt(ponto);
        String somaStr= String.valueOf(pontosP7);
        Log.e("Pontos:",somaStr);

        if (op==R.id.rdbCP7){
            Toast.makeText(this, "Resposta Correta", Toast.LENGTH_SHORT).show();
            pontosP7 +=1;

        }
        else{
            Toast.makeText(this, "Resposta Errada", Toast.LENGTH_SHORT).show();
        }
        String pontoStr;
        pontoStr = String.valueOf(pontosP7);
        Log.e("Pontos Somados:",pontoStr);
        Intent TP8 = new Intent(TelaPergunta7.this,TelaPergunta8.class);
        TP8.putExtra("PontosJogadorP7",pontoStr);

        String nome7= tVNomeP7.getText().toString();
        TP8.putExtra("NomeJogador8",nome7);

        startActivity(TP8);

    }
}