package com.example.aula1mob2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    
    EditText edUsuario,edSenha;
    Button btLoga;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        edUsuario = findViewById(R.id.edtUsuario);
        edSenha = findViewById(R.id.edtSenha);
        btLoga = findViewById(R.id.btnLogin);
    }
    int tentativas = 0;
    public void logar (View v){
        String Senha,Usuario;
        Usuario = edUsuario.getText().toString();
        Senha = edSenha.getText().toString();

        if (edUsuario.getText().toString().isEmpty()){
            edUsuario.setError("Usuario Obrigatório");
        }
        else if (edSenha.getText().toString().isEmpty()){
            edSenha.setError("Digite a Senha");
        }
        else {

            if (Senha.equals("1234") && Usuario.equals("Gustavo")) {
                Toast.makeText(this, "Ok", Toast.LENGTH_SHORT).show();

                Intent Itela2 = new Intent(MainActivity.this, tela2.class);

                Bundle dados = new Bundle();

                dados.putString("valor1", Usuario);
                dados.putString("valor2", Senha);

                Itela2.putExtras(dados);
                startActivity(Itela2);
            } else if (tentativas == 2) {
                btLoga.setEnabled(false);
            } else {
                tentativas = tentativas + 1;
                Toast.makeText(this, "Senha Incorreta" + tentativas, Toast.LENGTH_SHORT).show();
            }
        }

    }
}