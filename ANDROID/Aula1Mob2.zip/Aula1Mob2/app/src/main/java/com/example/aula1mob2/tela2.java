package com.example.aula1mob2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class tela2 extends AppCompatActivity {
    TextView txtvOla;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        txtvOla = findViewById(R.id.txtOla);
        Intent Itela2 = getIntent();
        Bundle recebe = Itela2.getExtras();

        txtvOla.setText(recebe.getString("valor1"));

    }
}