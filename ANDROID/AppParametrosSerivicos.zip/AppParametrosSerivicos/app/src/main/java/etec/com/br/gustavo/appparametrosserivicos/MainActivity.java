package etec.com.br.gustavo.appparametrosserivicos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edNome,edFone,edEmail,edEndereco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edNome = findViewById(R.id.edtNome);
        edFone = findViewById(R.id.edtFone);
        edEmail = findViewById(R.id.edtEmail);
        edEndereco = findViewById(R.id.edtEndereco);
    }
    public  void enviar(View v){
        Intent tela2 = new Intent(MainActivity.this,SegundaTela.class);
        tela2.putExtra("nome",edNome.getText().toString());
        tela2.putExtra("fone",edFone.getText().toString());
        tela2.putExtra("email",edEmail.getText().toString());
        tela2.putExtra("endereco",edEndereco.getText().toString());
        startActivity(tela2);
        Toast.makeText(this, "Dados Enviados com sucesso!", Toast.LENGTH_LONG).show();
    }
}