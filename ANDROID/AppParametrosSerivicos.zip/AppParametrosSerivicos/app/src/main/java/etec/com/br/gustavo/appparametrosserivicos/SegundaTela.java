package etec.com.br.gustavo.appparametrosserivicos;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class SegundaTela extends AppCompatActivity {
    TextView txtnome,txtfone,txtemail,txtendereco;

    String nomeRecebido,foneRecebido,emailRecebido,enderecoRecebido;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_tela);

        Intent telaAtual = getIntent();
        Bundle valores = telaAtual.getExtras();

        txtnome = findViewById(R.id.txtNome);
        txtfone = findViewById(R.id.txtFone);
        txtemail = findViewById(R.id.txtEmail);
        txtendereco = findViewById(R.id.txtEndereco);

        nomeRecebido = valores.getString("nome");
        foneRecebido = valores.getString("fone");
        emailRecebido = valores.getString("email");
        enderecoRecebido = valores.getString("endereco");

        txtnome.setText(nomeRecebido);
        txtfone.setText(foneRecebido);
        txtemail.setText(emailRecebido);
        txtendereco.setText(enderecoRecebido);
    }

    public  void fazerLigacao(View v){
        AlertDialog.Builder mensagem = new AlertDialog.Builder(this);

        mensagem.setTitle("Opções");

        mensagem.setMessage("O que deseja fazer?");

        mensagem.setPositiveButton("ligar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
                Uri uri = Uri.parse("tel:"+foneRecebido);
                Intent ligar = new Intent(Intent.ACTION_DIAL,uri);
                startActivity(ligar);
            }
        });
        mensagem.setNegativeButton("Whatsapp", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
                String contact = "+55 "+foneRecebido;
                String url = "https://api.whatsapp.com/send?phone=" + contact;
                try {
                    PackageManager pm = getPackageManager();
                    pm.getPackageInfo("com.whatsapp", PackageManager.GET_ACTIVITIES);
                    Intent whatsapp = new Intent(Intent.ACTION_VIEW);
                    whatsapp.setData(Uri.parse(url));
                    startActivity(whatsapp);
                }catch (PackageManager.NameNotFoundException e){
                    Toast.makeText(SegundaTela.this, "O WhatsApp não está instalado no seu Aparelho", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        });
        mensagem.show();
    }
    public  void enviarEmail(View v){

        String mailto = "mailto:"+emailRecebido + "?cc="+""+"&subject="+ Uri.encode("Email de teste pelo app") + "&body=" + Uri.encode("");

        Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
        emailIntent.setData(Uri.parse(mailto));

        try {
            startActivity(emailIntent);
        }catch (ActivityNotFoundException e){
            Toast.makeText(this, "Erro ao enviar o Email "+e, Toast.LENGTH_SHORT).show();
        }
    }

    public void abrirMapa(View v){
        Uri gmmIntentUri = Uri.parse("geo:0,0?q=" + enderecoRecebido);
        Intent mapIntent = new Intent(Intent.ACTION_VIEW,gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        startActivity(mapIntent);

    }
}