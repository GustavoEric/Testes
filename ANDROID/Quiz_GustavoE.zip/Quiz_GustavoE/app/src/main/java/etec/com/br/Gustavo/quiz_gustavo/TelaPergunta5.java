package etec.com.br.Gustavo.quiz_gustavo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TelaPergunta5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_pergunta5);
    }
}