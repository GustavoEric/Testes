package com.example.quiz_gustavoeric;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PerguntaTela7 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta_tela7);
    }
}